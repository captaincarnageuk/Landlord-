# Sanctuary Properties

A simple responsive PWA for managing rental properties. It works in a phone or desktop browser and can be installed as an app when hosted over HTTPS.

## Included in this first version
- Colourful dashboard
- Property records
- Tenant and rent details
- Mortgage details and automatic equity calculation
- Income/expense tracker
- Maintenance tracker
- Compliance date fields
- Local browser storage
- JSON backup export
- Responsive phone/PC layout

## Important
This prototype stores data locally in the browser. It is not yet a cloud-synchronised multi-device database. For phone + PC access to the same live data, the next step is to connect it to a secure cloud database/authentication layer.

## Hosting
Upload the files to any static HTTPS host (for example Netlify, Vercel or GitHub Pages). Once hosted, open the site on iPhone/PC and use the browser's Add to Home Screen/install option.
